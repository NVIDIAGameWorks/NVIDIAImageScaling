Overview:
This zip file include localized UI strings for NIS SDK's

HOW TO USE:
Each worksheet inside the SDK Localization Strings en-US.xlsx file list the UI Strings for each SDK.  Please find the corresponding language inside the NIS-Developer-Localization-Strings\ folder.  Each language is represented by the postfix of "_[Language]-[Country]".